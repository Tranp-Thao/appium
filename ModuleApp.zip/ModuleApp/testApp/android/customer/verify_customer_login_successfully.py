import os
import time
import logging
import unittest

from mainApp.common.config import basetest
from mainApp.locators.common import otp as OTP
from mainApp.locators.android.customer import login as Login, home_default as cus_home_default, booking_detail, \
    finding_driver, arriving_driver, trip_detail, rating
from Libraries.UnittestHTMLReport import HTMLReport


class TestFunction(unittest.TestCase):

    def test_user_login_successfully(self):
        app_ver = "Android_customer_Staging451_v1.1.47(5)_15.3.2019.apk"
        udid = "5203b083ec4463e9"
        # udid = "77859006"
        self.cus_driver = basetest.BaseTest(app_ver, udid)
        self.cus_driver.set_udid(udid)

        self.cus_driver.mobile_util.turn_on_gps()
        self.phone = "0767116599"
        self.otpValue = "4444"

        logging.info("Step 1 Action: [Customer] - Start app.")
        self.login = Login.Customer(self.cus_driver)
        self.otp = OTP.OTP(self.cus_driver)
        self.cus_home = cus_home_default.Home_Default(self.cus_driver)

        logging.info("Step 2 Action: [Customer] - User enter valid phone number.")
        self.login.enter_phone_number(self.phone)  # 0768094104 0909097225
        self.login.click_on_login_btn()

        logging.info("Step 2 Expected Result: [Customer] - Verify Auth OTP screen is displayed.")
        self.verify_auth_otp_is_displayed()

        logging.info("Step 3 Action: [Customer] - User enter valid otp number.")
        self.otp.enter_valid_otp(self.otpValue)

        logging.info("Step 3 Expected Result: [Customer] - verify Home Default is displayed.")
        self.verify_login_successful()

    def verify_auth_otp_is_displayed(self):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.first_pin_input()),
                        "        first pin Input is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.second_pin_input()),
                        "        second pin Input is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.third_pin_input()),
                        "        third pin Input is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.forth_pin_input()),
                        "        forth pin Input is displayed")

    def customer_login(self, phone, otp_value, lat, long):
        self.cus_driver.mobile_util.turn_on_gps()
        self.cus_driver.mobile_util.set_location(lat, long)
        self.login.enter_phone_number(phone)
        self.login.click_on_login_btn()
        self.verify_auth_otp_is_displayed()
        self.otp.enter_valid_otp(otp_value)
        self.verify_login_successful()

    def verify_login_successful(self):
        self.verify_home_default_is_displayed()

    def verify_home_default_is_displayed(self):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.view_menu_ico()), "View_menu_ico is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.title()), "Home_default_title is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.center_location_pin_ico()), "Center_location_pin_ico is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.confirm_my_location_btn()), "Confirm_my_location_btn is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.view_pick_up_input()), "Pick_up_input is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.view_drop_off_input()), "Drop_off_input is displayed")

        self.assertTrue(self.cus_home.HOME_DEFAULT_TITLE in self.cus_home.title().text, "Home_default_title is displayed correctly")
        self.assertTrue( "" in self.cus_home.view_drop_off_input().text, "Drop Off Input is displayed empty.")

if __name__ == '__main__':
    report_file_name = '{}_test_{}'.format(os.path.basename(__file__), time.strftime("%Y-%m-%d_%H-%M-%S"))
    unittest.main(testRunner=HTMLReport.TestRunner(
        report_file_name=report_file_name,  # Report file name, if not assigned, will use "test+ timestamp"
        output_path='reports',  # Save the folder name, the default "report"
        title=os.path.basename(__file__),  # Report title, default "test report"
        description='Verify ACL of Admin Panel',  # Report description, default "Test Description"
        thread_count=1,  # Number of concurrent threads (out of order execution test), default number 1
        thread_start_wait=3,  # Each thread startup delay, default 0 s
        sequential_execution=False,  # Whether to execute in the order of add (addTests),
        # Will wait for an addTests to complete, then execute the next one, default False
        # If tearDownClass exists in the use case, it is recommended to set it to True.
        # Otherwise tearDownClass will be executed after all use case threads have finished executing.
        lang='xx'  # Language, default "en" - English
    ))
