import os
import time
import logging
import unittest

from mainApp.common.config import basetest
from mainApp.locators.common import otp as OTP
from mainApp.locators.android.customer import login as Login, home_default as cus_home_default, booking_detail, \
    finding_driver, arriving_driver, trip_detail, rating, menu, logout
from Libraries.UnittestHTMLReport import HTMLReport


class TestFunction(unittest.TestCase):

    def test_book_trip(self):
        # Hard code data
        app_cus_ver = "Android_customer_Staging451_v1.1.47(5)_15.3.2019.apk"
        cus_udid = "XVV7N16B28004467"
        # driver_udid = "77859006"
        # udid = "XVV7N16B28004467"
        phone = "0767116599"
        otpValue = "4444"
        long = "106.704981"
        lat = "10.787902"
        driver_long = "106.702647"
        driver_lat = "10.785707"
        self.start_address = "2 Nguyễn Bỉnh Khiêm, Bến Nghé, Quận 1, Hồ Chí Minh, Việt Nam"
        self.end_address = "Toa nha Viettel"
        self.note = "J Mar 20 testing"
        self.driver_rating = "4.9"
        self.driver_name = "JASMINE VU DELIVERY"
        self.driver_number = "51A-678.90"
        self.payment_option = "Tiền mặt"
        app_cus_ver = ""
        self.cus_driver = basetest.BaseTest(app_cus_ver, cus_udid)
        self.login = Login.Customer(self.cus_driver)
        self.otp = OTP.OTP(self.cus_driver)
        self.book = booking_detail.Booking(self.cus_driver)
        self.cus_home = cus_home_default.Home_Default(self.cus_driver)
        self.finding = finding_driver.FindingDriver(self.cus_driver)
        self.arriving = arriving_driver.ArrivingDriver(self.cus_driver)
        self.trip_details = trip_detail.RideDetail(self.cus_driver)
        self.cus_rating_driver = rating.Rating(self.cus_driver)
        self.cus_menu = menu.Menu(self.cus_driver)
        self.cus_log_out = logout.Customer(self.cus_driver)
        self.promo = "car4  25k"

        # Start [Customer] App
        # set [Customer] location
        self.customer_login(phone, otpValue, lat, long)

        self.verify_home_default_is_displayed()
        self.verify_drop_down_input_in_view_is_displayed_correctly()
        self.verify_pick_up_input_in_view_is_displayed_correctly(self.start_address)

        # [Customer] Booking
        self.cus_home.set_drop_down_address(self.end_address)
        self.verify_pick_up_input_in_view_is_displayed_correctly(self.start_address)
        self.verify_drop_down_input_in_view_is_displayed_correctly(self.end_address)
        self.book.select_vehicle(2)
        self.book.click_on_payment_mode_confirm()
        self.book.select_payment_method()
        self.book.click_on_promotion_confirm_btn()
        self.promo = self.book.select_promotion(self.promo)# is selected
        self.book.click_on_add_note_btn()
        self.book.set_note_for_driver(self.note)
        self.book.click_on_save_note_btn()

        # [Customer] book trip
        self.book.click_on_book_trip_btn()

        # [Customer] Find driver and cancel
        self.verify_finding_driver_is_displayed()

        # [Customer] Arriving driver
        self.verify_customer_view_when_driver_is_accepted_trip()

        self.verify_arriving_home_is_displayed_correctly(0)

        # [Customer] Arrived driver
        self.verify_customer_view_when_driver_is_accepted_trip()

        self.verify_arriving_home_is_displayed_correctly(1)


        self.swipe_to_trip_detail()

        self.verify_customer_trip_detail_is_displayed_correctly()

        # after driver end trip
        self.verify_customer_end_trip_is_displayed_correctly()

        self.cus_driver.mobile_el_util.tab_on(self.cus_rating_driver.end_ride_rating_star_ico("1"))
        self.assertEqual(self.cus_rating_driver.end_ride_rating_star_ico("1").text, "Tệ")
        self.verify_customer_rating_driver_is_displayed_correctly("1")

        self.cus_driver.mobile_el_util.tab_on(self.cus_rating_driver.end_ride_rating_star_ico("2"))
        self.assertEqual(self.cus_rating_driver.end_ride_rating_star_ico("2").text, "Không tốt")
        self.verify_customer_rating_driver_is_displayed_correctly("2")

        self.cus_driver.mobile_el_util.tab_on(self.cus_rating_driver.end_ride_rating_star_ico("3"))
        self.assertEqual(self.cus_rating_driver.end_ride_rating_star_ico("3").text, "Tạm ổn")
        self.verify_customer_rating_driver_is_displayed_correctly("3")

        self.cus_driver.mobile_el_util.tab_on(self.cus_rating_driver.end_ride_rating_star_ico("4"))
        self.assertEqual(self.cus_rating_driver.end_ride_rating_star_ico("4").text, "Tốt")
        self.verify_customer_rating_driver_is_displayed_correctly("4")

        self.cus_driver.mobile_el_util.tab_on(self.cus_rating_driver.end_ride_rating_star_ico("5"))
        self.assertEqual(self.cus_rating_driver.end_ride_rating_star_ico("5").text, "Tuyệt :)")
        self.verify_customer_rating_driver_is_displayed_correctly("5")

        self.cus_driver.mobile_el_util.tab_on(self.cus_rating_driver.end_ride_feedback_reasons_list()[0])
        self.cus_driver.mobile_el_util.tab_on(self.cus_rating_driver.end_ride_submit_feedback_btn())

        self.verify_home_default_is_displayed()
        self.verify_drop_down_input_in_view_is_displayed_correctly()
        self.verify_pick_up_input_in_view_is_displayed_correctly(self.start_address)

        self.customer_logout()

        self.tearDown()


    # --------------------------- Methods -------------------------------------------
    def customer_logout(self):
        self.cus_driver.mobile_el_util.tab_on(self.cus_home.view_menu_ico())
        self.cus_driver.mobile_el_util.tab_on(self.cus_menu.customer_name_txt())
        self.cus_driver.mobile_el_util.tab_on(self.cus_log_out.log_out_btn())
        self.cus_driver.mobile_el_util.tab_on(self.cus_log_out.ok_btn())
        pass

    def verify_customer_trip_detail_is_displayed_correctly(self):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.title()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.driver_rating_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.start_ride_driver_name_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.start_ride_driver_number_plates_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.driver_vehicle_type_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.ride_date_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.start_ride_fare_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.start_ride_promotion_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.start_ride_payment_method_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.start_ride_pick_up_address_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.start_ride_drop_up_address_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.end_ride_distance_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.end_ride_estimate_time_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.trip_details.cancel_btn()))

        self.end_address = "Toà nhà Viettel Tower, Hẻm 285 Cách Mạng Tháng Tám, Phường 12, Quận 10, Hồ Chí Minh, Việt Nam"
        self.trip_title = "Chi tiết chuyến đi"
        self.vehicle = "beCar 4 chỗ"
        self.fare_cur = "50.000₫"
        self.fare_promo = "-25.000₫"
        self.distance = "4.0 km"
        self.est_time = "14 phút"
        self.driver_name = "Jasmine vu Delivery"

        self.assertEqual(self.trip_details.title().text, self.trip_title)
        self.assertEqual(self.trip_details.driver_rating_txt().text, self.driver_rating)
        self.assertEqual(self.trip_details.start_ride_driver_name_txt().text, self.driver_name)
        self.assertEqual(self.trip_details.start_ride_driver_number_plates_txt().text, self.driver_number)
        self.assertEqual(self.trip_details.driver_vehicle_type_txt().text, self.vehicle)
        self.assertTrue("29 Th3, 2019 | " in self.trip_details.ride_date_txt().text)
        self.assertEqual(self.trip_details.start_ride_fare_txt().text, self.fare_cur)
        self.assertEqual(self.trip_details.start_ride_promotion_txt().text, self.fare_promo)
        self.assertEqual(self.trip_details.start_ride_payment_method_txt().text, self.payment_option)
        self.assertEqual(self.trip_details.start_ride_pick_up_address_txt().text, self.start_address)
        self.assertEqual(self.trip_details.start_ride_drop_up_address_txt().text, self.end_address)
        self.assertEqual(self.trip_details.end_ride_distance_txt().text, self.distance)
        self.assertEqual(self.trip_details.end_ride_estimate_time_txt().text, self.est_time)
        self.assertEqual(self.trip_details.cancel_btn().text, "Hủy chuyến")

    def verify_customer_end_trip_is_displayed_correctly(self):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.title()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_rating_driver.thank_you_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_rating_driver.payment_type_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_rating_driver.fare_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_rating_driver.view_ride_details_btn()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_rating_driver.end_ride_rating_ride_question_txt()))

        fare_final = "25.000₫"
        self.assertEqual(self.cus_home.title().text, "Đánh giá chuyến đi")
        self.assertEqual(self.cus_rating_driver.thank_you_txt().text, "Cảm ơn bạn đã chọn dịch vụ của be")
        self.assertEqual(self.cus_rating_driver.payment_type_txt().text, "THANH TOÁN BẰNG TIỀN MẶT")
        self.assertEqual(self.cus_rating_driver.fare_txt().text, fare_final)
        self.assertEqual(self.cus_rating_driver.end_ride_rating_ride_question_txt().text, "Chuyến đi của bạn như thế nào?")

    def verify_customer_rating_driver_is_displayed_correctly(self, number="1"):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_rating_driver.end_ride_share_your_exp_input()))
        self.assertEqual(self.cus_rating_driver.end_ride_share_your_exp_input().text, "Chia sẻ trải nghiệm của bạn")

        if number == "1" or number == "2":
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[0].text, "Không hoàn thành chuyến")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[1].text, "Vi phạm luật giao thông")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[2].text, "Quấy rối, vũ lực")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[3].text, "Hăm dọa, xúc phạm")
        elif number == "2":
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[4].text, "Khác")
        elif number == "3":
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[0].text, "Thái độ khó chịu")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[1].text, "Mất tập trung khi lái xe")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[2].text, "Chất lượng xe")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[3].text, "Chuyến đi bị ngắt quãng")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[4].text, "Lộ trình không hợp lý")
        elif number == "4":
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[0].text, "Thái độ khó chịu")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[1].text, "Mất tập trung khi lái xe")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[2].text, "Chất lượng xe")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[3].text, "Chuyến đi bị ngắt quãng")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[4].text, "Lộ trình không hợp lý")
        elif number == "5":
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[0].text, "Trò chuyện vui vẻ")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[1].text, "Xe đẹp, sạch sẽ")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[2].text, "Dịch vụ xuất sắc")
            self.assertEqual(self.cus_rating_driver.end_ride_feedback_reasons_list()[3].text, "Chuyến đi an toàn")

    def swipe_to_trip_detail(self):
        element = self.cus_driver.driver.find_element_by_id("imvRideDetails")
        self.cus_driver.driver.swipe(364, 800, 355, 460, 243)

    def verify_arriving_home_is_displayed_correctly(self, state = 0):
        self.assertEqual(self.arriving.promotion_name_txt().text, self.promo)
        self.assertEqual(self.arriving.driver_rating_txt().text, self.driver_rating)
        self.assertEqual(self.arriving.driver_name_txt().text, self.driver_name)
        self.assertEqual(self.arriving.driver_car_number_txt().text, self.driver_number)
        self.assertEqual(self.arriving.payment_option_txt().text, self.payment_option)

        if state == 0:
            self.assertEqual(self.arriving.final_drop_down_location_txt().text, self.start_address)
            self.assertEqual(self.arriving.state_txt().text, "Tài xế đang đến đón bạn...")
        elif state == 1:
            self.assertEqual(self.arriving.final_drop_down_location_txt().text, self.end_address)
            self.assertEqual(self.arriving.state_txt().text, "Đã tới điểm đón")

    def verify_customer_view_when_driver_is_accepted_trip(self):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.final_drop_down_location_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.promotion_name_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.state_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.chat_btn()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.driver_rating_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.driver_name_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.driver_car_number_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.payment_option_txt()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.call_driver_btn()))
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.arriving.show_option_ico()))

    def verify_finding_driver_is_displayed(self):
        try:
            self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.finding.radar_icon()), "radar_icon is displayed")
            self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.finding.assigning_pickup_location()), "assigning_pickup_location is displayed")
            self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.finding.assigning_drop_up_location()), "assigning_drop_up_location is displayed")
            self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.finding.finding_driver_txt()), "finding_driver_txt is displayed")
            self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.finding.cancel_btn()), "cancel_btn is displayed")
            self.assertTrue(self.finding.FINDING_DRIVER_TXT in self.finding.finding_driver_txt().text, "Home_default_title is displayed correctly")
        except:
            logging.info("finding driver is complete")

    def verify_pick_up_input_in_view_is_displayed_correctly(self, address=""):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.view_pick_up_input()), "Pick_up_input is displayed")
        self.assertEqual(address, self.cus_home.view_pick_up_input().get_attribute('text'), "pick up address is displayed correctly.")

    def verify_drop_down_input_in_view_is_displayed_correctly(self, act_address="Nhập điểm đến"):
        exp_address = self.cus_home.view_drop_off_input().text
        self.assertEqual(exp_address, exp_address, "drop down address is displayed correctly.")

    def verify_drop_down_input_is_displayed_correctly(self, address="Nhập điểm đến"):
        self.assertEquals(address, self.cus_home.drop_off_input().get_attribute('text'), "drop down address is displayed correctly.")

    def customer_login(self, phone, otp_value, lat, long):
        self.cus_driver.mobile_util.turn_on_gps()
        self.cus_driver.mobile_util.set_location(lat, long)
        self.login.enter_phone_number(phone)
        self.login.click_on_login_btn()
        self.verify_auth_otp_is_displayed()
        self.otp.enter_valid_otp(otp_value)
        self.verify_home_default_is_displayed()

    def verify_auth_otp_is_displayed(self):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.first_pin_input()), "        first pin Input is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.second_pin_input()), "        second pin Input is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.third_pin_input()), "        third pin Input is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.forth_pin_input()), "        forth pin Input is displayed")

    def verify_auth_cus_otp_is_displayed(self, phoneNm):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.cus_phone_number_txt()),"        phone Number Input is displayed")
        self.assertTrue(phoneNm[1:9] in self.otp.cus_phone_number_txt().text, "        Enter OTP Successfully")
        self.verify_auth_otp_is_displayed()

    def verify_home_default_is_displayed(self):
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.view_menu_ico()), "View_menu_ico is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.title()), "Home_default_title is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.center_location_pin_ico()), "Center_location_pin_ico is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.confirm_my_location_btn()), "Confirm_my_location_btn is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.view_pick_up_input()), "Pick_up_input is displayed")
        self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.cus_home.view_drop_off_input()), "Drop_off_input is displayed")

        self.assertTrue(self.cus_home.HOME_DEFAULT_TITLE in self.cus_home.title().text, "Home_default_title is displayed correctly")
        self.assertTrue( "" in self.cus_home.view_drop_off_input().text, "Drop Off Input is displayed empty.")

if __name__ == '__main__':
    report_file_name = '{}_test_{}'.format(os.path.basename(__file__), time.strftime("%Y-%m-%d_%H-%M-%S"))
    unittest.main(testRunner=HTMLReport.TestRunner(
        report_file_name=report_file_name,  # Report file name, if not assigned, will use "test+ timestamp"
        output_path='reports',  # Save the folder name, the default "report"
        title=os.path.basename(__file__),  # Report title, default "test report"
        description='Verify ACL of Admin Panel',  # Report description, default "Test Description"
        thread_count=1,  # Number of concurrent threads (out of order execution test), default number 1
        thread_start_wait=3,  # Each thread startup delay, default 0 s
        sequential_execution=False,  # Whether to execute in the order of add (addTests),
        # Will wait for an addTests to complete, then execute the next one, default False
        # If tearDownClass exists in the use case, it is recommended to set it to True.
        # Otherwise tearDownClass will be executed after all use case threads have finished executing.
        lang='xx'  # Language, default "en" - English
    ))
