import os
import time
import logging
import unittest

from mainApp.common.config import basetest
from mainApp.locators.common import otp as OTP
from mainApp.locators.android.customer import login as Login, home_default as cus_home_default, booking_detail, \
    finding_driver, arriving_driver, trip_detail, rating
from Libraries.UnittestHTMLReport import HTMLReport


class TestFunction(unittest.TestCase):

    def test_install_app(self):

        logging.info("Step 1: [Customer] - Uninstall app.")
        add_ver = "beDriver_Staging_1.1.43(1).374_200319_release.apk"
        udid = "77859006"
        self.cus_base = basetest.BaseTest(add_ver, udid, False)
        self.cus_base.set_udid(udid)

        if self.cus_base.mobile_util.is_app_installed(self.cus_base.server_env.get_app_package()):
            self.cus_base.mobile_util.remove_app(self.cus_base.server_env.get_app_package())

        logging.info("Step 2: [Customer] - Install app at current device")
        if not self.cus_base.mobile_util.is_app_installed(self.cus_base.server_env.get_app_package()):
            self.cus_base.mobile_util.install_app(self.cus_base.server_env.get_app_local_path())

if __name__ == '__main__':
    report_file_name = '{}_test_{}'.format(os.path.basename(__file__), time.strftime("%Y-%m-%d_%H-%M-%S"))
    unittest.main(testRunner=HTMLReport.TestRunner(
        report_file_name=report_file_name,  # Report file name, if not assigned, will use "test+ timestamp"
        output_path='reports',  # Save the folder name, the default "report"
        title=os.path.basename(__file__),  # Report title, default "test report"
        description='Verify ACL of Admin Panel',  # Report description, default "Test Description"
        thread_count=1,  # Number of concurrent threads (out of order execution test), default number 1
        thread_start_wait=3,  # Each thread startup delay, default 0 s
        sequential_execution=False,  # Whether to execute in the order of add (addTests),
        # Will wait for an addTests to complete, then execute the next one, default False
        # If tearDownClass exists in the use case, it is recommended to set it to True.
        # Otherwise tearDownClass will be executed after all use case threads have finished executing.
        lang='xx'  # Language, default "en" - English
    ))
