# import os
# import time
# import logging
# import unittest
#
# from mainApp.common.config import basetest
# from mainApp.locators.common import otp as OTP
# from mainApp.locators.android.driver import home_default as driver_home_default, login, menu
# from Libraries.UnittestHTMLReport import HTMLReport
#
#
# class TestFunction(unittest.TestCase):
#
#     def test_install_app(self):
#
#         logging.info("Step 1: [Driver] - Uninstall app.")
#         add_ver = "beDriver_Staging_1.1.43(1).374_200319_release.apk"
#         # udid = "5203b083ec4463e9"
#         udid = "77859006"
#         self.driver_base = basetest.BaseTest(add_ver, udid, False)
#         self.driver_base.set_udid(udid)
#
#         if self.driver_base.mobile_util.is_app_installed(self.driver_base.server_env.get_app_package()):
#             self.driver_base.mobile_util.remove_app(self.driver_base.server_env.get_app_package())
#
#         logging.info("Step 2: [Driver] - Install app at current device")
#         if not self.driver_base.mobile_util.is_app_installed(self.driver_base.server_env.get_app_package()):
#             self.driver_base.mobile_util.install_app(self.driver_base.server_env.get_app_local_path())
#
#         logging.info("Step 3: [Driver] - Start app.")
#         self.driver_base.setUp()
#
#     def test_user_login_successfully(self):
#         add_ver = "beDriver_Staging_1.1.43(1).374_200319_release.apk"
#         udid = "77859006"
#         # udid = "77859006"
#         self.driver_base = basetest.BaseTest(add_ver, udid)
#         self.driver_base.set_udid(udid)
#
#         self.driver_base.mobile_util.turn_on_gps()
#         self.phone = "0768094104"
#         self.otpValue = "4444"
#
#         logging.info("Step 1 Action: [Driver] - Start app.")
#
#         logging.info("Step 2 Action: [Driver] - User enter valid phone number.")
#         _login = login.Driver(self.driver_base)
#         otp = OTP.OTP(self.driver_base)
#
#         _login.enter_phone_number(self.phone)  # 0768094104 0909097225
#         _login.click_on_login_btn()
#
#         logging.info("Step 2 Expected Result: [Driver] - Verify Auth OTP screen is displayed.")
#         otp.verify_auth_driver_otp_is_displayed(self.phone)
#
#         logging.info("Step 3 Action: [Driver] - User enter valid otp number.")
#         otp.enter_valid_otp(self.otpValue)
#
#         logging.info("Step 3 Expected Result: [Driver] - verify Home Default is displayed.")
#         _login.verify_login_successful()
#
#     def test_home_option(self):
#         add_ver = "beDriver_Staging_1.1.43(1).374_200319_release.apk"
#         udid = "77859006"
#         # udid = "77859006"
#         self.driver_base = basetest.BaseTest(add_ver, udid)
#         self.driver_base.set_udid(udid)
#
#         self.driver_base.mobile_util.turn_on_gps()
#         self.phone = "0768094104"
#         self.otpValue = "4444"
#
#         self.driver_login(self.phone, self.otpValue)
#         _menu = menu.Menu(self.driver_base)
#         _home = driver_home_default.Home_Default(self.driver_base)
#
#         self.driver_base.mobile_el_util.tab_on(_menu.home_option())
#         _home.verify_home_default_is_displayed()
#
#     def test_performance_rate_option(self):
#         pass
#
#
#
#
#     def driver_login(self, phone, otp_value):
#         _login = login.Driver(self.driver_base)
#         _otp = OTP.OTP(self.driver_base)
#
#         _login.enter_phone_number(phone)
#         _login.click_on_login_btn()
#         _otp.verify_auth_otp_is_displayed(phone)
#         _otp.enter_valid_otp(otp_value)
#         _login.verify_login_successful()
#
#     def test_book_trip(self):
#         pass
#
#
#
#         pass
#
#
#
#
#
#
# if __name__ == '__main__':
#     report_file_name = '{}_test_{}'.format(os.path.basename(__file__), time.strftime("%Y-%m-%d_%H-%M-%S"))
#     unittest.main(testRunner=HTMLReport.TestRunner(
#         report_file_name=report_file_name,  # Report file name, if not assigned, will use "test+ timestamp"
#         output_path='reports',  # Save the folder name, the default "report"
#         title=os.path.basename(__file__),  # Report title, default "test report"
#         description='Verify ACL of Admin Panel',  # Report description, default "Test Description"
#         thread_count=1,  # Number of concurrent threads (out of order execution test), default number 1
#         thread_start_wait=3,  # Each thread startup delay, default 0 s
#         sequential_execution=False,  # Whether to execute in the order of add (addTests),
#         # Will wait for an addTests to complete, then execute the next one, default False
#         # If tearDownClass exists in the use case, it is recommended to set it to True.
#         # Otherwise tearDownClass will be executed after all use case threads have finished executing.
#         lang='xx'  # Language, default "en" - English
#     ))
