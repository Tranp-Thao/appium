import logging

from appium.webdriver.common.touch_action import TouchAction
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

class MobileElement():
    isFound = True
    count = 2
    WAITING_TIME = 5

    def __init__(self, driver):
        self.driver = driver

    # ~\\
    # General method about action on Element
    def find_el_by_id(self, value, time=WAITING_TIME):
        element = None
        try:
            self.wait = WebDriverWait(self.driver, time )
            element = self.wait.until(EC.element_to_be_clickable((By.ID, value)))
            self.clear()
            return element
        except NoSuchElementException :
            self.isFound = False
            self.count =- 1
            logging.info("        No Such Element.")
        except StaleElementReferenceException:
            self.isFound = False
            self.count =- 1
            logging.info("        Stale Element Reference.")

        if not self.isFound and self.count > 0:
            self.find_el_by_id(value)

    def clear(self):
        self.isFound = True
        self.count = 2

    def find_els_by_id(self, value, time=WAITING_TIME):
        element = None
        try:
            self.wait = WebDriverWait(self.driver, time)
            element = self.wait.until(EC.visibility_of_all_elements_located((By.ID, value)))
            self.clear()
            return element
        except NoSuchElementException:
            self.isFound = False
            self.count = - 1
            logging.info("        No Such Element.")
        except StaleElementReferenceException:
            self.isFound = False
            self.count = - 1
            logging.info("        Stale Element Reference.")

        if not self.isFound and self.count > 0:
            self.find_els_by_id(value)

    def find_el_by_xpath(self, value, time=WAITING_TIME):
        element = None
        try:
            self.wait = WebDriverWait(self.driver, time )
            element = self.wait.until(EC.element_to_be_clickable((By.XPATH, value)))
            self.clear()
            return element
        except NoSuchElementException:
            self.isFound = False
            self.count = - 1
            logging.info("        No Such Element.")
        except StaleElementReferenceException:
            self.isFound = False
            self.count = - 1
            logging.info("        Stale Element Reference.")

        if not self.isFound and self.count > 0:
            self.find_el_by_xpath(value)

    def find_els_by_xpath(self, value, time=WAITING_TIME):
        element = None
        try:
            self.wait = WebDriverWait(self.driver, time)
            element = self.wait.until(EC.visibility_of_all_elements_located((By.XPATH, value)))
            self.clear()
            return element
        except NoSuchElementException:
            self.isFound = False
            self.count = - 1
            logging.info("        No Such Element.")
        except StaleElementReferenceException:
            self.isFound = False
            self.count = - 1
            logging.info("        Stale Element Reference.")

        if not self.isFound and self.count > 0:
            self.find_els_by_xpath(value)

    def get_device_gps(self):
        location = self.driver.location
        logging.info("        GPS device = " + location)

    def tab_on(self, element):
        actions = TouchAction(self.driver)
        actions.tap(element)
        actions.perform()

    def click_on(self, element):
        element.click()

        # element.click()

    def enter_value(self, element, value):
        element.clear()
        element.send_keys(value)
        logging.info("        Enter " + value)

    def press_key(self, key):
        logging.info("        Press " + key)


