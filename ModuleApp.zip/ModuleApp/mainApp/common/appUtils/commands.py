
# Contain adb command to use check app

ADB_SHELL = "adb "

CHECK_APP_INSTALLED = " shell pm list packages "
INSTALL_APP = " install "
UNINSTALL_APP = " uninstall "
ENTER_NUMBER = " shell input keyevent KEYCODE_"
ENABLE_GLOBAL_LOCATION = " shell settings put secure location_providers_allowed +gps"
DISABLE_GLOBAL_LOCATION = " shell settings put secure location_providers_allowed -gps"

