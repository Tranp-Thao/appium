# Get time

def get_current_date():
    pass

