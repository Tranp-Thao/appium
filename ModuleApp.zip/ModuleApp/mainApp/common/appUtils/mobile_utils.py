import logging
import subprocess
import unittest

from mainApp.common.appUtils import commands as commands

class MobileUtils():
    WAITING_TIME = 10
    is_displayed = False
    is_enable = False
    count = 3

    def __init__(self, driver, server_env):
        self.driver = driver
        self.server_env = server_env

    #~\\
    #Use command check app
    @staticmethod
    def call_adb(command, app_path =""):
        return subprocess.check_output(command + app_path, shell=True)

    def get_udid(self):
        if self.server_env.get_udid():
            return "-s " + self.server_env.get_udid()
        else:
            return None

    def is_app_installed(self, app_path):
        try:
            path = MobileUtils.call_adb(commands.ADB_SHELL + MobileUtils.get_udid(self) + commands.CHECK_APP_INSTALLED, app_path)
            if path == b'':
                logging.info("        App is not installed.")
                return False
            else:
                logging.info("        App is installed.")
                return True
        except:
            logging.info("        App is not installed.")
            return False

    def install_app(self, app_path):
        try :
            MobileUtils.call_adb(commands.ADB_SHELL + MobileUtils.get_udid(self) + commands.INSTALL_APP, app_path)
            logging.info("App is installed.")
        except Exception as e:
            logging.info("type error: " + str(e))

    def remove_app(self, app_path):
        MobileUtils.call_adb(commands.ADB_SHELL + MobileUtils.get_udid(self) + commands.UNINSTALL_APP, app_path)
        logging.info("App is removed.")

    def enter_number_keyboard(self, key):
        MobileUtils.call_adb(commands.ADB_SHELL + MobileUtils.get_udid(self) + commands.ENTER_NUMBER, key)
        logging.info("Enter number = " + key)

    def turn_on_gps(self):
        MobileUtils.call_adb(commands.ADB_SHELL + MobileUtils.get_udid(self) + commands.ENABLE_GLOBAL_LOCATION, )
        logging.info("Enable global location")

    def turn_off_gps(self):
        MobileUtils.call_adb(commands.ADB_SHELL + MobileUtils.get_udid(self) + commands.DISABLE_GLOBAL_LOCATION, )
        logging.info("Disable global location")

    def set_location(self, latitude, longitude, altitude=10):
        self.driver.set_location(latitude, longitude, altitude)
        logging.info("Set global location: latitude = " + latitude + " - longitude = " +longitude + " - altitude = " + str(altitude))

    def get_location(self):
        pass

    def reset_mock_location_app(self):
        pass

    def is_element_displayed(self, element):

        try:
            element.is_displayed()
            self.is_displayed = True
            self.clear()
        except:
            self.is_displayed = False
            self.count -= 1

        if (not self.is_displayed) and self.count > 0:
            self.is_element_displayed(element)

        return self.is_displayed

    def is_element_enable(self, element):

        try:
            element.is_enabled()
            self.is_enable = True
            self.clear()
        except:
            self.is_enable = False
            self.count -= 1

        if (not self.is_displayed) and self.count > 0:
            self.is_element_displayed(element)

        return self.is_enable


    def clear(self):
        self.is_displayed = True
        self.count = 3
