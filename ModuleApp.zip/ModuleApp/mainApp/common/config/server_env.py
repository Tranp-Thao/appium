import os

class AppimDriver:
    APPUM_LNK = "http://127.0.0.1:"
    APPIUM_PORT = "4723"
    APPUM_SUB_LNK = "/wd/hub"
    APP_VER = ""
    APP_CUSTOMER_PACKAGE = "xyz.be.customer"
    APP_CUSTOMER_ACTIVITY = "xyz.be.customer.SplashNewActivity"
    APP_DRIVER_PACKAGE = "xyz.be.driver"
    APP_DRIVER_ACTIVITY = "xyz.be.driver.ui.DriverSplashActivity"
    APP_LOCAL_PATH = ""
    UDID = ""

    def __init__(self, app_ver):
        self.APP_VER = app_ver

    def PATH(p):
        return os.path.abspath(
            os.path.join(os.path.dirname(__file__), '..', '..', '.','..//apps/'+ p)
        )

    def get_appium_driver(self):
        return self.APPUM_LNK + self.APPIUM_PORT + self.APPUM_SUB_LNK

    def get_app_local_path(self):
        return AppimDriver.PATH(self.APP_VER)

    def get_app_ver(self):
        return self.APP_VER

    def get_app_package(self):
        if "DRIVER" in self.APP_VER.upper():
            return self.APP_DRIVER_PACKAGE
        return self.APP_CUSTOMER_PACKAGE

    def get_app_activity(self):
        if "DRIVER" in self.APP_VER.upper():
            return self.APP_DRIVER_ACTIVITY
        return self.APP_CUSTOMER_ACTIVITY

    def set_app_local_path(self, path):
        self.APP_LOCAL_PATH = path

    def set_app_package(self, path):
        self.APP_CUSTOMER_PACKAGE = path

    def set_app_activity(self, path):
        self.APP_CUSTOMER_ACTIVITY = path

    def set_app_ver(self, path):
        self.APP_VER = path

    def set_udid(self, udid):
        self.UDID = udid

    def get_udid(self):
        return self.UDID
