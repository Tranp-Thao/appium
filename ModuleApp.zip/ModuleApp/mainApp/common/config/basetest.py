from appium import webdriver
from mainApp.common.config import desired_capabilities, server_env
from mainApp.common.appUtils import mobile_element_utils, mobile_utils
import unittest

class BaseTest(object):

    driver = None
    mobile_util = None
    mobile_el_util = None

    def __init__(self, app_ver, udid, is_start=True):
        self.server_env = server_env.AppimDriver(app_ver)
        self.app_ver = app_ver
        self.app_package = self.server_env.get_app_package()
        self.desired_caps = desired_capabilities.get_desired_capabilities(self.app_ver)
        self.set_udid(udid)
        if is_start:
            self.setUp()
        self.mobile_util = mobile_utils.MobileUtils(self.driver, self.server_env)
        self.mobile_el_util = mobile_element_utils.MobileElement(self.driver)

    def setUp(self):
        self.driver = webdriver.Remote(self.server_env.get_appium_driver(), self.desired_caps)

    def tearDown(self):
        self.driver.reset()
        self.driver.quit()

    def set_udid(self, udid):
        if udid:
            self.server_env.set_udid(udid)
            self.desired_caps = desired_capabilities.set_desired_capabilitie(self.desired_caps, "udid",udid)