from mainApp.common.config import server_env


def get_desired_capabilities(app):
	server = server_env.AppimDriver(app)

	desired_caps = {
		'platformName': 'Android',
		'deviceName': 'Android Emulator',
		'appPackage': server.get_app_package(),
	  	'appActivity': server.get_app_activity(),
		'automationName': 'UiAutomator2',
		'autoGrantPermissions': 'true',
		# 'newCommandTimeout' : 5 * 5,
		'clearSystemFiles' : 'true',
		'noReset' : 'true'
	}
	return desired_caps

def set_desired_capabilitie(desired_caps, cap, value):
	desired_caps[cap] = value
	return desired_caps



