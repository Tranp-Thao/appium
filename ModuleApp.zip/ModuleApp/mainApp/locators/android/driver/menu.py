import unittest

class Menu(unittest.TestCase):

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        super(Menu, self).__init__()

    def user_name_txt(self):
        return self.mobile_el_util.find_el_by_id("userName")

    def driver_rating_txt(self):
        return self.mobile_el_util.find_el_by_id("ratingValue")

    def home_option(self):
        return self.mobile_el_util.find_el_by_id("homeRl")

    def performance_rate_option(self):
        return self.mobile_el_util.find_el_by_id("rlPerformanceRate")

    def driver_wallet_option(self):
        return self.mobile_el_util.find_el_by_id("withdrawableWalletRl")

    def earnings_RL_option(self):
        return self.mobile_el_util.find_el_by_id("earningsRL")

    def incentives_RL_option(self):
        return self.mobile_el_util.find_el_by_id("incentivesRL")

    def history_RL_option(self):
        return self.mobile_el_util.find_el_by_id("historyRL")

    def inbox_RL_option(self):
        return self.mobile_el_util.find_el_by_id("inboxRL")

    def support_option(self):
        return self.mobile_el_util.find_el_by_id("inboxRL")

    def app_version_txt(self):
        return self.mobile_el_util.find_el_by_id("tvVersion")



