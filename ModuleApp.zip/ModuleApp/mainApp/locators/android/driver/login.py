from mainApp.locators.common import device_permission
from mainApp.locators.android.driver import home_default

class Driver(home_default.Home_Default, device_permission.Permission):

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        self.app_package = base.app_package
        self.driver = base.driver

    PHONE_LEGTH = 10;
    INTER_PHONE_NUMBER = "+84";

    def phone_number_input(self):
        return self.mobile_el_util.find_el_by_id("edtPhoneNo")

    def phone_login_btn(self):
        return self.mobile_el_util.find_el_by_id("btnGenerateOtp")

    def app_header_txt(self):
        return self.mobile_el_util.find_el_by_id("tvLabel")

    def app_name_header_txt(self):
        return self.mobile_el_util.find_el_by_id("tvBe")

    def enter_phone_number(self, phoneNm):
        self.close_gps_allow_btn()
        self.close_gps_allow_btn()
        self.mobile_el_util.enter_value(Driver.phone_number_input(self), phoneNm)

    def click_on_login_btn(self):
        self.mobile_el_util.tab_on(Driver.phone_login_btn(self))

    def verify_login_successful(self):
        self.verify_home_default_is_displayed()