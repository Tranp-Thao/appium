from mainApp.locators.common import device_permission
from mainApp.locators.android.driver import home_default

class Driver():

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        self.app_package = base.app_package
        self.driver = base.driver

    def title(self):
        return self.mobile_el_util.find_el_by_id("title")

    def driver_name_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewDriverName")

    def driver_rating_txt(self):
        return self.mobile_el_util.find_el_by_id("tvRating")

    def switch_max_sound(self):
        return self.mobile_el_util.find_el_by_id("switchMaxSound")

    def log_out_btn(self):
        return self.mobile_el_util.find_el_by_id("btLogout")

    def back_btn(self):
        return self.mobile_el_util.find_el_by_id("backBtn")