import unittest

class Home_Default(unittest.TestCase):

    HOME_DEFAULT_TITLE = "Đặt xe"

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        super(Home_Default, self).__init__()

    def status_btn(self):
        return self.mobile_el_util.find_el_by_id("tvStatus")

    def my_location_ico(self):
        return self.mobile_el_util.find_el_by_id("driverInitialMyLocationBtn")

    def menu_ico(self):
        return self.mobile_el_util.find_el_by_id("menuBtn")

    def verify_home_default_is_displayed(self):
        self.assertTrue(self.mobile_util.is_element_displayed(Home_Default.status_btn(self)), "status_btn is displayed")

    def click_on_status_btn(self):
        self.mobile_el_util.tab_on(Home_Default.status_btn(self))


