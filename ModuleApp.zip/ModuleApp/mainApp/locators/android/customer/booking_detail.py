import logging


class Booking():

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        self.base = base

    # View Booking
    def back_icon(self):
        return self.mobile_el_util.find_el_by_id("ivBackCircular")

    def start_ride_view_pick_up_ico(self):
        return self.mobile_el_util.find_el_by_id("ivBackCircular")

    def start_ride_view_drop_down_ico(self):
        return self.mobile_el_util.find_el_by_id("ivBackCircular")

    def view_vehicle_ico(self):
        return self.mobile_el_util.find_els_by_xpath("(//*[@contentDescription='Bản đồ trên Google']/*[contains(@contentDescription,'driver shown to customer.')])")

    # Booking
    def vehicle_type_ico(self, vehicle_name):
        return self.mobile_el_util.find_el_by_xpath("//*[contains(@text,'"+vehicle_name+"')]")

    def vehicle_type_name(self, vehicle_name):
        return self.mobile_el_util.find_el_by_xpath("//*[*[./*[contains(@text,'"+vehicle_name+"')]]]//*[@id='textViewVehicleName']")

    def vehicle_type_fare(self, vehicle_name):
        return self.mobile_el_util.find_el_by_xpath("//*[*[./*[contains(@text,'"+vehicle_name+"')]]]//*[@id='tvVehicleFare']")

    def payment_mode_confirm_btn(self):
        return self.mobile_el_util.find_el_by_id("linearLayoutPaymentModeConfirm")

    def payment_mode_confirm_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewPaymentModeValueConfirm")

    def payment_by_pay_gate(self):
        return self.mobile_el_util.find_el_by_id("relativeLayoutPayGate")

    def payment_by_pay_gates(self):
        return self.mobile_el_util.find_els_by_id("relativeLayoutPayGate")

    def payment_by_cash(self):
        return self.mobile_el_util.find_el_by_id("linearLayoutCash")

    def total_fare_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewTotalFareValue")

    def promotion_confirm_btn(self):
        return self.mobile_el_util.find_el_by_id("linearLayoutOfferConfirm")

    def promotion_confirm_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewOffersConfirm")

    def promotion_title(self):
        return self.mobile_el_util.find_el_by_id("tvAvailableOffers")

    def close_popup(self):
        return self.mobile_el_util.find_el_by_id("ivClose")

    def promotion_popup(self):
        return self.mobile_el_util.find_el_by_id("listViewPromoCoupons")

    def promotion_list(self):
        return self.mobile_el_util.find_els_by_xpath("//*[@id='listViewPromoCoupons']//*[@id='relative']")

    def no_promotion(self):
        return self.mobile_el_util.find_el_by_id("layoutNoOffer")

    def promotion_name_list(self):
        return self.mobile_el_util.find_els_by_xpath("//*[@id='listViewPromoCoupons']//*[@id='textViewOfferName']")

    def promotion_detail_ico_list(self, number):
        return self.mobile_el_util.find_els_by_xpath("//*[@id='listViewPromoCoupons']//*[@id='relative']["+number+"]//*[@id='ivTNC']")

    def promotion_choosen_ico(self, number):
        return self.mobile_el_util.find_els_by_xpath("//*[@id='listViewPromoCoupons']//*[@id='relative']["+number+"]//*[@id='imageViewRadio']")

    def promtion_detail_popup(self):
        return self.mobile_el_util.find_el_by_id("rl1")

    def promtion_detail_txt(self):
        return self.mobile_el_util.find_el_by_id("textMessage")

    def promtion_detail_ok_btn(self):
        return self.mobile_el_util.find_el_by_id("btnOk")

    def add_promotion_input(self):
        return self.mobile_el_util.find_el_by_id("etPromo")

    def add_note_btn(self):
        return self.mobile_el_util.find_el_by_id("linearLayoutNotes")

    def add_note_title(self):
        return self.mobile_el_util.find_el_by_id("tvNotesHeading")

    def note_input(self):
        return self.mobile_el_util.find_el_by_id("etNotes")

    def save_note_btn(self):
        return self.mobile_el_util.find_el_by_id("btnSaveNotes")

    def book_btn(self):
        return self.mobile_el_util.find_el_by_id("buttonConfirmRequest")

    # Booking Methods
    def select_vehicle(self, typ=1):
        if typ == 1:
            logging.info("Vehicle is bike")
            self.mobile_el_util.tab_on(Booking.vehicle_type_ico(self, "beBike"))

        elif typ == 2 :
            logging.info("Vehicle is car 4 seats")
            self.mobile_el_util.tab_on(Booking.vehicle_type_ico(self, "beCar 4"))

        else:
            logging.info("Vehicle is cả 7 seats")
            self.mobile_el_util.tab_on(Booking.vehicle_type_ico(self, "beCar 7"))

    def click_on_payment_mode_confirm(self):
        self.mobile_el_util.tab_on(Booking.payment_mode_confirm_txt(self))

    def select_payment_method(self, typ=2):
        if typ == 1:
            logging.info("Payment method is card")
            self.mobile_el_util.tab_on(Booking.payment_by_pay_gate(self))
        elif typ == 2:
            logging.info("Payment method is cash")
            self.mobile_el_util.tab_on(Booking.payment_by_cash(self))
        elif typ == 3:
            logging.info("Payment method is company")

    def click_on_promotion_confirm_btn(self):
        self.mobile_el_util.tab_on(Booking.promotion_confirm_btn(self))

    def select_promotion(self, promote = "0"):
        self.promo_text = ""
        try:
            promos = Booking.promotion_name_list(self)
            for promo in promos:
                if promo.text == promote:
                    self.promo_text = promo.text
                    self.mobile_el_util.click_on(promo)
                    break
                elif promote == "0":
                    self.promo_text = promo.text
                    self.mobile_el_util.click_on(promo)
                    break

            return self.promo_text
        except :
            promo_text = Booking.no_promotion(self).text
            self.mobile_el_util.click_on(Booking.no_promotion(self))
            return self.promo_text

    def click_on_add_note_btn(self):
        self.mobile_el_util.click_on(Booking.add_note_btn(self))

    def set_note_for_driver(self, note=""):
        self.mobile_el_util.enter_value(Booking.note_input(self), note)

    def click_on_book_trip_btn(self):
        self.mobile_el_util.tab_on(Booking.book_btn(self))

    def click_on_save_note_btn(self):
        self.mobile_el_util.tab_on(Booking.save_note_btn(self))