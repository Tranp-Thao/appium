import unittest

class Home_Default(unittest.TestCase):

    HOME_DEFAULT_TITLE = "Đặt xe"

    def __init__(self, driver):
        self._driver = driver
        super(Home_Default, self).__init__()

    def view_menu_ico(self):
        return self._driver.mobile_el_util.find_el_by_id("imageViewMenu")

    def title(self):
        return self._driver.mobile_el_util.find_el_by_id("tvScreenTitle")

    def center_location_pin_ico(self):
        return self._driver.mobile_el_util.find_el_by_id("centreLocationPin")

    def confirm_my_location_btn(self):
        return self._driver.mobile_el_util.find_el_by_id("confirmMyLocationBtn")

    def view_pick_up_input(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewInitialSearch")

    def pick_up_input(self):
        return self._driver.mobile_el_util.find_el_by_id("editTextSearch")

    def view_drop_off_input(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewDestSearch")

    def drop_off_input(self):
        return self._driver.mobile_el_util.find_el_by_id("editTextSearchDest")

    def set_drop_down_address(self, address=""):
        self.assertTrue(self._driver.mobile_util.is_element_displayed(Home_Default.view_pick_up_input(self)), "Pick_up_input is displayed")
        self.assertTrue(self._driver.mobile_util.is_element_displayed(Home_Default.view_drop_off_input(self)),"Drop_off_input is displayed")

        self._driver.mobile_el_util.tab_on(Home_Default.view_drop_off_input(self))
        self._driver.mobile_el_util.enter_value(Home_Default.drop_off_input(self), address)

        for view_search_address in Home_Default.view_search_addresses(self):
            address = view_search_address.text
            self._driver.mobile_el_util.tab_on(view_search_address)
            break

        return address

    def view_search_addresses(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewSearchAddress")

