from mainApp.locators.common import device_permission
from mainApp.locators.android.driver import home_default

class Customer(object):

    def __init__(self, driver):
        self._driver = driver

    def title(self):
        return self._driver.mobile_el_util.find_el_by_id("tvScreenTitle")

    def customer_name_txt(self):
        return self._driver.mobile_el_util.find_el_by_id("editTextUserName")

    def customer_email_txt(self):
        return self._driver.mobile_el_util.find_el_by_id("editTextEmail")

    def customer_phone_txt(self):
        return self._driver.mobile_el_util.find_el_by_id("editTextPhone")

    def save_address_btn(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewAddressBook_btn")

    def emergency_contact_btn(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewEmergencyContact")

    def log_out_btn(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewLogout")

    def edit_profile_ico(self):
        return self._driver.mobile_el_util.find_el_by_id("imageViewEditProfile")

    def ok_btn(self):
        return self._driver.mobile_el_util.find_el_by_id("btnOk")

    def cancel_btn(self):
        return self._driver.mobile_el_util.find_el_by_id("btnCancel")