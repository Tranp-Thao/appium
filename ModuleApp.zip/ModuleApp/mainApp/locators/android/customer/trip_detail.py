from mainApp.common.config import basetest

class RideDetail():

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        self.base = base

    def title(self):
        return self.mobile_el_util.find_el_by_id("tvTitle")

    def driver_rating_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewDriverRating")

    def start_ride_driver_name_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewDriverName")

    def end_ride_driver_name_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideDriverName")

    def start_ride_driver_number_plates_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewDriverCarNumber")

    def end_ride_driver_number_plates_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideDriverCarNumber")

    def start_ride_driver_vehicle_type_ico(self):
        return self.mobile_el_util.find_el_by_id("imageViewAutoIcon") # TODO

    def end_ride_driver_vehicle_type_ico(self):
        return self.mobile_el_util.find_el_by_id("imageViewEndRideAutoIcon")

    def driver_vehicle_type_txt(self):
        return self.mobile_el_util.find_el_by_id("tvVehicleType")

    def booking_id_txt(self):
        return self.mobile_el_util.find_el_by_id("tvBookingId")

    def ride_date_txt(self):
        return self.mobile_el_util.find_el_by_id("tvDateNTime")

    def start_ride_fare_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewFareValue")

    def end_ride_fare_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideFareValue")

    def start_ride_promotion_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewPromotionValue")

    def end_ride_promotion_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewDiscountValue")

    def start_ride_payment_method_txt(self):
        return self.mobile_el_util.find_el_by_id("tvPaymentMethodValue")

    def end_ride_payment_method_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideToBePaid")

    def end_ride_amt_to_be_paid_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideToBePaidValue")

    def note_txt(self):
        return self.mobile_el_util.find_el_by_id("editTextPhoneNumber") #TODO

    def start_ride_pick_up_address_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewStartLocationValue")

    def end_ride_pick_up_address_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideStartLocationValue")

    def start_ride_drop_up_address_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndLocationValue")

    def end_ride_drop_up_address_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideEndLocationValue")

    def start_ride_distance_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideDistanceValue")

    def end_ride_distance_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideDistanceValue")

    def start_ride_estimate_time_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewTimeValue")

    def end_ride_estimate_time_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideTimeValue")

    def end_ride_wait_time_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewEndRideWaitTimeValue")

    # Need Help button is same locator with cancel button
    def cancel_btn(self):
        return self.mobile_el_util.find_el_by_id("buttonEndRideOk")

    def verify_customer_trip_detail(self):

        pass