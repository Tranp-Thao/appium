import logging
from mainApp.locators.android.customer import home_default
from mainApp.locators.common import device_permission


class Customer(home_default.Home_Default, device_permission.Permission):

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        self.app_package = base.app_package
        self.driver = base.driver

    # Login Locators
    def phone_number_input(self):
        return self.mobile_el_util.find_el_by_id("editTextPhoneNumber")

    def phone_login_btn(self):
        return self.mobile_el_util.find_el_by_id("btnPhoneLogin")

    def app_header_txt(self):
        return self.mobile_el_util.find_el_by_id("tvJugnooTaxiPB")

    def app_name_header_txt(self):
        return self.mobile_el_util.find_el_by_id("tvJugnooTaxiPBe")

    def close_gps_allow_btn(self):
        try:
            self.gps_allow_btn().click()
        except:
            logging.info("App is not off gps")

    def close_disconnect_network(self):
        try:
            self.driver.find_element_by_id("btnOk").click()
        except:
            logging.info("App is not disconnect network")

    def enter_phone_number(self, phoneNm):
        self.close_gps_allow_btn()
        self.close_disconnect_network()
        self.mobile_el_util.enter_value(Customer.phone_number_input(self), phoneNm)

    def click_on_login_btn(self):
        self.mobile_el_util.tab_on(Customer.phone_login_btn(self))