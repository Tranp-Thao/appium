import unittest
import logging

class FindingDriver(object):
    FINDING_DRIVER_TXT = "Đang tìm tài xế"

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        super(FindingDriver, self).__init__()

    def radar_icon(self):
        return self.mobile_el_util.find_el_by_id("ivRadar")

    def assigning_pickup_location(self):
        return self.mobile_el_util.find_el_by_id("textViewAssigningPickupLocationClick")

    def assigning_drop_up_location(self):
        return self.mobile_el_util.find_el_by_id("textViewAssigningDropLocationClick")

    def finding_driver_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewFindingDriver")

    def cancel_btn(self):
        return self.mobile_el_util.find_el_by_id("initialCancelRideBtn")

    def click_on_cancel_btn(self):
        self.mobile_el_util.tab_on(FindingDriver.cancel_btn(self))