from mainApp.common.config import basetest

class Rating():

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        self.base = base
    # ~//
    # title is same to home_default title

    def thank_you_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewThanks")

    def payment_type_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewRSCashPaid")

    def fare_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewRSCashPaidValue")

    def view_ride_details_btn(self):
        return self.mobile_el_util.find_el_by_id("textViewRSInvoice")

    def end_ride_rating_ride_question_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewRSRateYourRide")

    def end_ride_rating_stars_ico(self):
        return self.mobile_el_util.find_els_by_xpath("(//*[@id='ratingBarRSFeedback']/*[@class='android.widget.TextView'])")

    def end_ride_rating_star_ico(self, number):
        return self.mobile_el_util.find_el_by_xpath("(//*[@id='ratingBarRSFeedback']/*[@class='android.widget.TextView'])[" + number + "]")


    def end_ride_feedback_reasons_grid(self):
        return self.mobile_el_util.find_el_by_id("gridViewRSFeedbackReasons")

    def end_ride_feedback_reasons_list(self):
        return self.mobile_el_util.find_els_by_id("textViewFeedbackReason")

    def end_ride_share_your_exp_input(self):
        return self.mobile_el_util.find_el_by_id("editTextRSFeedback")

    def end_ride_submit_feedback_btn(self):
        return self.mobile_el_util.find_el_by_id("buttonRSSubmitFeedback")

    def sos_btn(self, number):
        return self.mobile_el_util.find_el_by_id("imageViewHelp")

    def close_ico(self, number):
        return self.mobile_el_util.find_el_by_id("ivClose")