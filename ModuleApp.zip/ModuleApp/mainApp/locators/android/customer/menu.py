import unittest

class Menu(object):

    def __init__(self, driver):
        self._driver = driver
        super(Menu, self).__init__()

    def customer_name_txt(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewUserName")

    def customer_phone_txt(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewViewPhone")

    def home_option(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewMenu")[0]

    def introduce_option(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewMenu")[1]

    def promo_option(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewMenu")[2]

    def inbox_option(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewMenu")[3]

    def history_option(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewMenu")[4]

    def payment_option(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewMenu")[5]

    def support_option(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewMenu")[6]

    def more_option(self):
        return self._driver.mobile_el_util.find_els_by_id("textViewMenu")[7]

    def website_option(self):
        return self._driver.mobile_el_util.find_el_by_id("tvWebsite")

    def about_us_option(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewAbout")

    def tnc_option(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewTNC")

    def privacy_option(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewPrivacy")

    def like_us_option(self):
        return self._driver.mobile_el_util.find_el_by_id("textViewLikeUs")

    def app_version_option(self):
        return self._driver.mobile_el_util.find_el_by_id("tvAppVersion")

    def app_version_txt(self):
        return self._driver.mobile_el_util.find_el_by_id("tvAppVersionVal")
