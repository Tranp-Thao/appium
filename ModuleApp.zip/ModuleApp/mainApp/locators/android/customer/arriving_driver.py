
class ArrivingDriver():

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        self.base = base

    def final_drop_down_location_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewFinalDropLocationClick")

    def promotion_name_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewInRidePromoName")

    def state_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewInRideState")

    def chat_btn(self):
        return self.mobile_el_util.find_el_by_id("bChatDriver")

    def driver_rating_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewDriverRating")

    def driver_name_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewInRideDriverName")

    def driver_car_number_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewInRideDriverCarNumber")

    def payment_option_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewIRPaymentOptionValue")

    def fare_factor_txt(self):
        return self.mobile_el_util.find_el_by_id("textViewInRideFareFactor")

    def call_driver_btn(self):
        return self.mobile_el_util.find_el_by_id("buttonCallDriver")

    def show_option_ico(self):
        return self.mobile_el_util.find_el_by_id("rlShowOptions")