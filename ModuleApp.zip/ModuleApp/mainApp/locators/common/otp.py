class OTP():

    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util
        self.app_package = base.app_package
        self.base = base

    def cus_phone_number_txt(self):
        return self.mobile_el_util.find_el_by_id(self.app_package + ":id/textViewOtpNumber")

    def driver_phone_number_txt(self):
        return self.mobile_el_util.find_el_by_id(self.app_package + ":id/label_number")


    def first_pin_input(self):
        return self.mobile_el_util.find_el_by_id(self.app_package + ":id/pin_first_edittext")

    def second_pin_input(self):
        return self.mobile_el_util.find_el_by_id(self.app_package + ":id/pin_second_edittext")

    def third_pin_input(self):
        return self.mobile_el_util.find_el_by_id(self.app_package + ":id/pin_third_edittext")

    def forth_pin_input(self):
        return self.mobile_el_util.find_el_by_id(self.app_package + ":id/pin_forth_edittext")

    def resend_otp_lnk(self):
        return self.mobile_el_util.find_el_by_id(self.app_package + ":id/tv_resend_otp")

    def enter_valid_otp(self, otpValue):
        self.mobile_util.enter_number_keyboard(otpValue[0])
        self.mobile_util.enter_number_keyboard(otpValue[1])
        self.mobile_util.enter_number_keyboard(otpValue[2])
        self.mobile_util.enter_number_keyboard(otpValue[3])

    # def verify_auth_driver_otp_is_displayed(self, phoneNm):
    #     self.assertTrue(self.cus_driver.mobile_util.is_element_displayed(self.otp.driver_phone_number_txt()),
    #                     "phone Number Input is displayed")
    #     self.assertTrue(phoneNm[1:9] in self.otp.driver_phone_number_txt().text, "        Enter OTP Successfully")
    #     self.verify_auth_otp_is_displayed()
