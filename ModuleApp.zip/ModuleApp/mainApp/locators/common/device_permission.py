import logging

class Permission:
    def __init__(self, base):
        self.mobile_el_util = base.mobile_el_util
        self.mobile_util = base.mobile_util

    def gps_allow_btn(self):
        return self.mobile_el_util.find_el_by_xpath("//*[@id='permission_allow_button']")

    def disconnect_network_btn(self):
        return self.mobile_el_util.find_el_by_xpath("btnOk")

    def close_gps_allow_btn(self):
        try:
            self.mobile_el_util.tab_on(self.gps_allow_btn())
        except:
            logging.info("App is not off gps")

    def close_disconnect_network(self):
        try:
            self.mobile_el_util.tab_on(self.disconnect_network_btn())
        except:
            logging.info("App is not disconnect network")